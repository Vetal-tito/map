let NATO = [
['Country', 'NATO'],
['United States', '100'],
['Germany', '10']
]
